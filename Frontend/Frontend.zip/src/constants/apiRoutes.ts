// All API URLs in one place — never hardcode in components

const BASE = "http://localhost:5000/api/v1"

export const API_ROUTES = {
  ORDERS: {
    BASE:   `${BASE}/orders`,
    BY_ID:  (id: number) => `${BASE}/orders/${id}`,
  }
}

// Frontend page paths — no hardcoding in components
export const PAGE_ROUTES = {
  ADMIN:        "/admin",
  ORDER_CREATE: "/admin/create",
}

export default API_ROUTES