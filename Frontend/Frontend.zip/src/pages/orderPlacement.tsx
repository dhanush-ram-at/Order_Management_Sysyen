import { Box, Typography } from "@mui/material"
import Navbar from "../layouts/Navbar"
import OrderTable from "../components/OrderTable"  // ← fixed path

function OrderPlacement() {   // ← capital O — React requires this

  return (
    <>
      <Navbar />

      <Box p={3}>
        <Typography variant="h5">
          Orders Management
        </Typography>

        {/* OrderTable handles everything — filters, table, pagination, form */}
        <OrderTable />
      </Box>
    </>
  )

}

export default OrderPlacement