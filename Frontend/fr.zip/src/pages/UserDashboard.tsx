import { Box, Typography } from "@mui/material";
import Navbar from "../layouts/Navbar";
import AppButton from "../components/common/AppButton";
import { PAGE_ROUTES } from "../Routes/apiRoutes";
import { useNavigate } from "react-router-dom";

// User dashboard — simple page with just a "Create Order" button for now
function UserDashboard() {
  const navigate = useNavigate();

  return (
    <>
      <Navbar />
      <Box p={3}>
        <Typography variant="h5" mb={3}>Dashboard</Typography>

        {/* Clicking this goes to the order creation form */}
        <AppButton onClick={() => navigate(PAGE_ROUTES.ORDER_CREATE)}>
          Create Order
        </AppButton>
      </Box>
    </>
  );
}

export default UserDashboard;
