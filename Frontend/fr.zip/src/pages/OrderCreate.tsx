import { Box, Typography, RadioGroup, FormControlLabel, Radio } from "@mui/material";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import Navbar from "../layouts/Navbar";
import { createOrder } from "../services/api";
import { PAGE_ROUTES } from "../Routes/apiRoutes";
import AppTextField from "../components/common/AppTextField";
import AppButton from "../components/common/AppButton";
import type { OrderFormData } from "../types/order";

// Empty starting values for the form
const EMPTY_FORM: OrderFormData = {
  customer_name: "",
  product_name: "",
  order_date: "",
  price: "",
  quantity: "",
  payment_method: "CASH",
  order_status: "Pending",   // always Pending when user creates — hidden from user
};

function OrderCreate() {
  const navigate = useNavigate();

  const [form, setForm]  = useState<OrderFormData>(EMPTY_FORM);
  const [files, setFiles] = useState<FileList | null>(null);

  // Validation errors — one per field
  const [errors, setErrors] = useState<Partial<OrderFormData>>({});

  // Update one field when user types
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Validate all required fields — show errors immediately when they occur
  const validate = () => {
    const newErrors: Partial<OrderFormData> = {};

    if (!form.customer_name.trim()) newErrors.customer_name = "Customer name is required";
    if (!form.product_name.trim()) newErrors.product_name = "Product name is required";
    if (!form.order_date) newErrors.order_date = "Order date is required";
    if (!form.price) newErrors.price = "Price is required";
    else if (isNaN(Number(form.price))) newErrors.price = "Price must be a number";
    if (!form.quantity) newErrors.quantity = "Quantity is required";
    else if (isNaN(Number(form.quantity))) newErrors.quantity = "Quantity must be a number";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
  if (!validate()) return;

  try {
    console.log("FORM:", form); // optional debug

    await createOrder({
      ...form,
      price: Number(form.price),
      quantity: Number(form.quantity),
    });

    await Swal.fire({
      title: "Order Placed!",
      text: "Your order has been created successfully.",
      icon: "success",
      timer: 1500,
      showConfirmButton: false,
    });

    const user = JSON.parse(localStorage.getItem("user") || "{}");
    navigate(user.role === "ADMIN" ? PAGE_ROUTES.ADMIN_DASHBOARD : PAGE_ROUTES.USER_DASHBOARD);

  } catch (err: any) {
    console.log(err.response?.data); // 🔥 VERY IMPORTANT

    Swal.fire({
      title: "Error",
      text: err.response?.data?.message || "Failed to create order",
      icon: "error",
    });
  }
};

  // Back button — go to dashboard without saving
  const handleBack = () => {
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    navigate(user.role === "ADMIN" ? PAGE_ROUTES.ADMIN_DASHBOARD : PAGE_ROUTES.USER_DASHBOARD);
  };

  return (
    <>
      <Navbar />
      <Box p={3} maxWidth={600}>
        <Typography variant="h5" mb={1}>Create Order</Typography>

        {/* Customer Name */}
        <AppTextField
          label="Customer Name"
          name="customer_name"
          value={form.customer_name}
          onChange={handleChange}
          error={!!errors.customer_name}
          helperText={errors.customer_name}
        />

        {/* Product Name */}
        <AppTextField
          label="Product Name"
          name="product_name"
          value={form.product_name}
          onChange={handleChange}
          error={!!errors.product_name}
          helperText={errors.product_name}
        />

        {/* Order Date */}
        <AppTextField
          label="Order Date"
          name="order_date"
          type="date"
          value={form.order_date}
          onChange={handleChange}
          error={!!errors.order_date}
          helperText={errors.order_date}
          InputLabelProps={{ shrink: true }}
        />

        {/* Price */}
        <AppTextField
          label="Price"
          name="price"
          value={form.price}
          onChange={handleChange}
          error={!!errors.price}
          helperText={errors.price}
        />

        {/* Quantity */}
        <AppTextField
          label="Quantity"
          name="quantity"
          value={form.quantity}
          onChange={handleChange}
          error={!!errors.quantity}
          helperText={errors.quantity}
        />

        {/* Payment method — radio buttons */}
        <Typography sx={{ mt: 2 }}>Payment Method</Typography>
        <RadioGroup
          name="payment_method"
          value={form.payment_method}
          onChange={handleChange}
          row
        >
          <FormControlLabel value="CASH" control={<Radio />} label="Cash" />
          <FormControlLabel value="CARD" control={<Radio />} label="Card" />
          <FormControlLabel value="UPI"  control={<Radio />} label="UPI"  />
        </RadioGroup>


        {/* File upload */}
        <Typography sx={{ mt: 2 }}>Upload Files (optional)</Typography>
        <input
          type="file"
          multiple
          accept=".jpg,.jpeg,.png,.pdf"
          onChange={(e) => setFiles(e.target.files)}
        />

        {/* Place Order + Back buttons */}
        <Box sx={{ display: "flex", gap: 2, mt: 3 }}>
          <AppButton onClick={handleSubmit} fullWidth>
            Place Order
          </AppButton>
          <AppButton variant="outlined" onClick={handleBack} fullWidth>
            Back
          </AppButton>
        </Box>

      </Box>
    </>
  );
}

export default OrderCreate;
