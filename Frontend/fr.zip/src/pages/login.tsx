import { useState } from "react"
import axios from "axios"

function Login() {

    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
      
    const handleLogin = async () => {
        try{
            const res = await axios.post(
            "http://localhost:5000/api/v1/auth/login",
            { email, password }
            )

            // Save the token
            localStorage.setItem("token", res.data.accessToken)
            localStorage.setItem("refreshToken", res.data.refreshToken)

            // Save the user
            localStorage.setItem("user", JSON.stringify(res.data.user))

            window.location.href = "/login"
        }
        catch(err) {
            alert("Invalid email or password")
        }
    }
  

  return (
    <div>
      <input placeholder="email" onChange={(e)=>setEmail(e.target.value)} />
      <input placeholder="password" type="password" onChange={(e)=>setPassword(e.target.value)} />
      <button onClick={handleLogin}>Login</button>
    </div>
  )
}

export default Login