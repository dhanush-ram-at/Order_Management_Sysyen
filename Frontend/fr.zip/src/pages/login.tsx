import { useState } from "react";
import axios from "axios";
import { Box, Typography, Button } from "@mui/material";
import { API_ROUTES, PAGE_ROUTES } from "../Routes/apiRoutes";
import AppTextField from "../components/common/AppTextField";
import AppButton from "../components/common/AppButton";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Validation errors — shown below each field
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [loginError, setLoginError] = useState("");  // general error (wrong creds)

  // Validate fields and return true if everything is ok
  const validate = () => {
    let valid = true;

    // Reset old errors first
    setEmailError("");
    setPasswordError("");

    if (!email) {
      setEmailError("Email is required");
      valid = false;
    }
    if (!password) {
      setPasswordError("Password is required");
      valid = false;
    }
    return valid;
  };

  const handleLogin = async () => {
    // Don't call API if validation fails
    if (!validate()) return;

    try {
      const res = await axios.post(API_ROUTES.AUTH.LOGIN, { email, password });

      // Save token and user info to localStorage
      localStorage.setItem("token", res.data.accessToken);
      localStorage.setItem("refreshToken", res.data.refreshToken);
      localStorage.setItem("user", JSON.stringify(res.data.user));

      // Redirect based on role — ADMIN goes to /admin, USER goes to /user
      const role = res.data.user.role;
      window.location.href =
        role === "ADMIN" ? PAGE_ROUTES.ADMIN_DASHBOARD : PAGE_ROUTES.USER_DASHBOARD;

    } catch {
      setLoginError("Invalid email or password");
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", mt: 10 }}>
      <Typography variant="h5" mb={3}>Order Management System</Typography>

      <Box sx={{ display: "flex", flexDirection: "column", width: 350 }}>

        {/* Email field — shows error if empty */}
        <AppTextField
          label="Email"
          name="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={!!emailError}
          helperText={emailError}
        />

        {/* Password field — shows error if empty */}
        <AppTextField
          label="Password"
          name="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={!!passwordError}
          helperText={passwordError}
        />

        {/* General error e.g. wrong credentials */}
        {loginError && (
          <Typography color="error" sx={{ mt: 1 }}>{loginError}</Typography>
        )}

        {/* Login button */}
        <AppButton onClick={handleLogin} fullWidth sx={{ mt: 2 }}>
          Login
        </AppButton>

        {/* Register button — goes to /register */}
        <AppButton
          variant="outlined"
          onClick={() => window.location.href = PAGE_ROUTES.REGISTER}
          fullWidth
          sx={{ mt: 1 }}
        >
          Register
        </AppButton>

      </Box>
    </Box>
  );
}

export default Login;
