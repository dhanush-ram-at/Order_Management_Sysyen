import { Box, Typography } from "@mui/material";
import Navbar from "../layouts/Navbar";
import AdminOrderTable from "../components/admin/AdminOrderTable";

// Admin dashboard — shows all orders with search, filter, sort, edit, cancel, delete
function AdminDashboard() {
  return (
    <>
      <Navbar />
      <Box p={3}>
        <Typography variant="h5" mb={1}>Orders Management</Typography>
        <AdminOrderTable />
      </Box>
    </>
  );
}

export default AdminDashboard;
