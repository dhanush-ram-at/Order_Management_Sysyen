import { useState } from "react";
import { Box, Typography } from "@mui/material";
import Swal from "sweetalert2";
import { PAGE_ROUTES } from "../Routes/apiRoutes";
import { registerUser } from "../services/api";
import AppTextField from "../components/common/AppTextField";
import AppButton from "../components/common/AppButton";

function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Validation errors — one for each field
  const [nameError, setNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  // Validate all fields — returns true only if all are filled correctly
  const validate = () => {
    let valid = true;

    // Reset previous errors
    setNameError("");
    setEmailError("");
    setPasswordError("");

    if (!name.trim()) {
      setNameError("Name is required");
      valid = false;
    }

    if (!email.trim()) {
      setEmailError("Email is required");
      valid = false;
    } else if (!email.includes("@")) {
      // Very basic email check
      setEmailError("Enter a valid email");
      valid = false;
    }

    if (!password) {
      setPasswordError("Password is required");
      valid = false;
    } else if (password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      valid = false;
    }

    return valid;
  };

  const handleRegister = async () => {
    // Stop here if any field has an error
    if (!validate()) return;

    try {
      // Role is always USER — users cannot register as ADMIN
      await registerUser({ name, email, password });

      // Success popup — then go to login
      await Swal.fire({
        title: "Registered!",
        text: "Account created. Please login.",
        icon: "success",
        confirmButtonText: "Go to Login",
      });

      window.location.href = PAGE_ROUTES.LOGIN;

    } catch (err: any) {
      // Show error popup — e.g. "email already exists"
      Swal.fire({
        title: "Registration Failed",
        text: err?.response?.data?.message || "Something went wrong. Try again.",
        icon: "error",
      });
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", mt: 10 }}>
      <Typography variant="h5" mb={3}>Create Account</Typography>

      <Box sx={{ display: "flex", flexDirection: "column", width: 350 }}>

        {/* Name field */}
        <AppTextField
          label="Name"
          name="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          error={!!nameError}
          helperText={nameError}
        />

        {/* Email field */}
        <AppTextField
          label="Email"
          name="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={!!emailError}
          helperText={emailError}
        />

        {/* Password field */}
        <AppTextField
          label="Password"
          name="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={!!passwordError}
          helperText={passwordError}
        />

        {/* Register button */}
        <AppButton onClick={handleRegister} fullWidth sx={{ mt: 2 }}>
          Register
        </AppButton>

        {/* Back to login */}
        <AppButton
          variant="outlined"
          onClick={() => window.location.href = PAGE_ROUTES.LOGIN}
          fullWidth
          sx={{ mt: 1 }}
        >
          Back to Login
        </AppButton>

      </Box>
    </Box>
  );
}

export default Register;
