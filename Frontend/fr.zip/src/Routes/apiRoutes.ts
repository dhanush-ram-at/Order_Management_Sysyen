const BASE = "http://localhost:5000/api/v1";

// ── API routes — these are the backend URLs we call ──────────────────────────
export const API_ROUTES = {
  AUTH: {
    LOGIN:    `${BASE}/auth/login`,
    REGISTER: `${BASE}/auth/register`,   // POST — name, email, password
    REFRESH:  `${BASE}/auth/refresh`,
  },
  ORDERS: {
    BASE:   `${BASE}/orders`,
    BY_ID:  (id: number) => `${BASE}/orders/${id}`,
  },
};

// ── Page routes — these are the React Router URL paths ──────────────────────
export const PAGE_ROUTES = {
  LOGIN:           "/login",
  REGISTER:        "/register",        // new register page
  ADMIN_DASHBOARD: "/admin",           // admin sees all orders
  USER_DASHBOARD:  "/user",            // user sees create order button
  ORDER_CREATE:    "/create",
};

export default API_ROUTES;
