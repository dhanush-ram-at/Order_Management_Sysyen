import { Navigate } from "react-router-dom";
import { PAGE_ROUTES } from "./apiRoutes";

type Props = {
  children: JSX.Element;
  role?: "ADMIN" | "USER";  // optional — if given, checks the user's role too
};

// ProtectedRoute — blocks users who are not logged in
// If a role is passed, it also blocks users with the wrong role
function ProtectedRoute({ children, role }: Props) {
  const token = localStorage.getItem("token");
  const user  = JSON.parse(localStorage.getItem("user") || "{}");

  // Not logged in → go to login
  if (!token) {
    return <Navigate to={PAGE_ROUTES.LOGIN} replace />;
  }

  // Wrong role → send them to their correct dashboard
  if (role && user.role !== role) {
    const correctPath =
      user.role === "ADMIN" ? PAGE_ROUTES.ADMIN_DASHBOARD : PAGE_ROUTES.USER_DASHBOARD;
    return <Navigate to={correctPath} replace />;
  }

  return children;
}

export default ProtectedRoute;
