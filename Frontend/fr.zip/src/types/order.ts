// How one order looks like when it comes from the backend
export type Order = {
  order_id:       number;
  order_code:     string;
  customer_name:  string;
  order_date:     string;
  product_name:   string;
  price:          number;
  quantity:       number;
  total_amount:   number;
  payment_method: string;
  order_status:   string;
  remarks:        string | null;   // cancellation reason stored here
  created_at:     string;
};

// What the create/edit form holds before submitting
export type OrderFormData = {
  customer_name:  string;
  product_name:   string;
  order_date:     string;
  price:          string;
  quantity:       string;
  payment_method: string;
  order_status:   string;
};

// Filters the user can apply in the table
export type OrderFilters = {
  page:   number;
  search: string;   // searches customer name (backend param: "customer")
  status: string;
  sort:   string;
};
