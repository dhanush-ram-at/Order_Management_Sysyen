import { Routes, Route, Navigate } from "react-router-dom";

// Pages
import HandleLogin from "./pages/login";
import Register       from "./pages/register";
import AdminDashboard from "./pages/AdminDashboard";
import UserDashboard  from "./pages/UserDashboard";
import OrderCreate from "./pages/OrderCreate";

// Route helpers
import ProtectedRoute from "./Routes/protectedroute";
import { PAGE_ROUTES } from "./Routes/apiRoutes";

function App() {
  const token = localStorage.getItem("token");
  const user  = JSON.parse(localStorage.getItem("user") || "{}");

  // Decide where "/" should redirect based on login + role
  const homeRedirect = () => {
    if (!token) return PAGE_ROUTES.LOGIN;
    return user.role === "ADMIN" ? PAGE_ROUTES.ADMIN_DASHBOARD : PAGE_ROUTES.USER_DASHBOARD;
  };

  return (
    <Routes>
      {/* Root → redirect based on auth + role */}
      <Route path="/" element={<Navigate to={homeRedirect()} replace />} />

      {/* Login — if already logged in, skip to dashboard */}
      <Route
        path={PAGE_ROUTES.LOGIN}
        element={token ? <Navigate to={homeRedirect()} replace /> : <HandleLogin />}
      />

      {/* Register — open to everyone */}
      <Route path={PAGE_ROUTES.REGISTER} element={<Register />} />

      {/* Admin dashboard — only ADMIN role allowed */}
      <Route
        path={PAGE_ROUTES.ADMIN_DASHBOARD}
        element={
          <ProtectedRoute role="ADMIN">
            <AdminDashboard />
          </ProtectedRoute>
        }
      />

      {/* User dashboard — only USER role allowed */}
      <Route
        path={PAGE_ROUTES.USER_DASHBOARD}
        element={
          <ProtectedRoute role="USER">
            <UserDashboard />
          </ProtectedRoute>
        }
      />

      {/* Create order — both roles can access */}
      <Route
        path={PAGE_ROUTES.ORDER_CREATE}
        element={
          <ProtectedRoute>
            <OrderCreate />
          </ProtectedRoute>
        }
      />

      {/* Anything else → login */}
      <Route path="*" element={<Navigate to={PAGE_ROUTES.LOGIN} replace />} />
    </Routes>
  );
}

export default App;
