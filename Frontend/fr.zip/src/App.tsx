import { Routes, Route } from "react-router-dom"
import HandleLogin from "../src/pages/login"
import OrderPlacement from "../src/pages/orderPlacement"
import OrderCreate    from "./pages/OrderCreate"
import { PAGE_ROUTES } from "./Routes/apiRoutes"
import ProtectedRoute from "../src/Routes/protectedroute"



function App() {
  return (
    <Routes>
      <Route
        path={PAGE_ROUTES.ADMIN}
        element={
          <ProtectedRoute>
            <OrderPlacement />
          </ProtectedRoute>
        }
      />


      <Route
        path={PAGE_ROUTES.Login}
        element={
          token ? <OrderPlacement /> : <HandleLogin />
        }
      />
      {/* <Route path={PAGE_ROUTES.Login} element={<HandleLogin/>}/>
      <Route path={PAGE_ROUTES.ADMIN} element={<OrderPlacement />} /> */}
      <Route path={PAGE_ROUTES.ORDER_CREATE} element={<OrderCreate />}   />
    </Routes>
  )
}

export default App