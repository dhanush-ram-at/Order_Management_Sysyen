import { Dialog, DialogTitle, DialogContent, DialogActions, RadioGroup, FormControlLabel, Radio, Typography } from "@mui/material";
import { useState, useEffect } from "react";
import Swal from "sweetalert2";
import { updateOrder } from "../../services/api";
import AppTextField from "../common/AppTextField";
import AppSelect from "../common/AppSelect";
import AppButton from "../common/AppButton";
import type { Order, OrderFormData } from "../../types/order";

type Props = {
  open: boolean;
  setOpen: (v: boolean) => void;
  order: Order | null;              // the order being edited
  reloadOrders: () => void;         // refresh the table after save
};

// Status options — admin can change status to anything
const STATUS_OPTIONS = [
  { value: "Pending", label: "Pending" },
  { value: "Delivered", label: "Delivered" },
  { value: "Cancelled", label: "Cancelled" },
];

function EditOrderDialog({ open, setOpen, order, reloadOrders }: Props) {

  // Form state — pre-filled when dialog opens
  const [form, setForm] = useState<OrderFormData>({
    customer_name: "",
    product_name: "",
    order_date: "",
    price: "",
    quantity: "",
    payment_method: "CASH",
    order_status: "Pending",
  });

  // Validation errors — one per field
  const [errors, setErrors] = useState<Partial<OrderFormData>>({});

  // When a different order is selected, fill in its values
  useEffect(() => {
    if (order) {
      setForm({
        customer_name: order.customer_name,
        product_name: order.product_name,
        // order_date from DB is ISO string — we only need YYYY-MM-DD for the date input
        order_date: order.order_date.slice(0, 10),
        price: String(order.price),
        quantity: String(order.quantity),
        payment_method: order.payment_method,
        order_status: order.order_status,
      });
      setErrors({});  // clear old errors when opening fresh
    }
  }, [order]);

  // Update one field in the form
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Validate all fields — returns true only if everything is filled
  const validate = () => {
    const newErrors: Partial<OrderFormData> = {};

    if (!form.customer_name.trim()) newErrors.customer_name = "Customer name is required";
    if (!form.product_name.trim()) newErrors.product_name  = "Product name is required";
    if (!form.order_date)  newErrors.order_date = "Order date is required";
    if (!form.price) newErrors.price = "Price is required";
    if (!form.quantity) newErrors.quantity = "Quantity is required";

    setErrors(newErrors);
    // If no errors object keys → all good
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;  // stop if validation fails

    try {
      await updateOrder(order!.order_id, form);

      // Success popup
      await Swal.fire({
        title: "Updated!",
        text: "Order updated successfully.",
        icon: "success",
        timer: 1500,
        showConfirmButton: false,
      });

      setOpen(false);
      reloadOrders();  // refresh the table

    } catch {
      Swal.fire({ title: "Error", text: "Failed to update order.", icon: "error" });
    }
  };

  const handleBack = () => {
    setOpen(false);  // close without saving
  };

  return (
    <Dialog open={open} onClose={handleBack} maxWidth="sm" fullWidth>
      <DialogTitle>Edit Order</DialogTitle>

      <DialogContent>

        {/* Customer name */}
        <AppTextField
          label="Customer Name"
          name="customer_name"
          value={form.customer_name}
          onChange={handleChange}
          error={!!errors.customer_name}
          helperText={errors.customer_name}
        />

        {/* Product name */}
        <AppTextField
          label="Product Name"
          name="product_name"
          value={form.product_name}
          onChange={handleChange}
          error={!!errors.product_name}
          helperText={errors.product_name}
        />

        {/* Order date */}
        <AppTextField
          label="Order Date"
          name="order_date"
          type="date"
          value={form.order_date}
          onChange={handleChange}
          error={!!errors.order_date}
          helperText={errors.order_date}
          InputLabelProps={{ shrink: true }}
        />

        {/* Price */}
        <AppTextField
          label="Price"
          name="price"
          value={form.price}
          onChange={handleChange}
          error={!!errors.price}
          helperText={errors.price}
        />

        {/* Quantity */}
        <AppTextField
          label="Quantity"
          name="quantity"
          value={form.quantity}
          onChange={handleChange}
          error={!!errors.quantity}
          helperText={errors.quantity}
        />

        {/* Payment method — radio buttons */}
        <Typography sx={{ mt: 2 }}>Payment Method</Typography>
        <RadioGroup
          name="payment_method"
          value={form.payment_method}
          onChange={handleChange}
          row
        >
          <FormControlLabel value="CASH" control={<Radio />} label="Cash" />
          <FormControlLabel value="CARD" control={<Radio />} label="Card" />
          <FormControlLabel value="UPI"  control={<Radio />} label="UPI"  />
        </RadioGroup>

        {/* Order status — only admin can change this */}
        <AppSelect
          label="Order Status"
          value={form.order_status}
          onChange={(val) => setForm({ ...form, order_status: val })}
          options={STATUS_OPTIONS}
        />

      </DialogContent>

      <DialogActions sx={{ p: 2, gap: 1 }}>
        {/* Back = close without saving */}
        <AppButton variant="outlined" onClick={handleBack}>
          Back
        </AppButton>
        {/* Save = validate + call API */}
        <AppButton onClick={handleSave}>
          Save Changes
        </AppButton>
      </DialogActions>
    </Dialog>
  );
}

export default EditOrderDialog;
