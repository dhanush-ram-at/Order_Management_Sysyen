import { Box, Chip } from "@mui/material";
import { DataGrid, type GridColDef } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import Swal from "sweetalert2";

import { getOrders, deleteOrder } from "../../services/api"; 
import OrderFilters from "./OrderFilters"; 
import EditOrderDialog from "./EditOrderDialog";
import CancelOrderDialog from "./CancelOrderDialog";
import AppButton from "../common/AppButton";
import type { OrderFilters as FilterType } from "../../types/order";
import type { Order } from "../../types/order";

// Default filters — what the table starts with on first load
const DEFAULT_FILTERS: FilterType = {
  page:   1,
  search: "",
  status: "",
  sort:   "order_date",
};

function AdminOrderTable() {

  const [orders, setOrders] = useState<Order[]>([]);
  const [total, setTotal] = useState(0);            // total count for pagination
  const [filters, setFilters] = useState<FilterType>(DEFAULT_FILTERS);

  // Edit dialog state
  const [openEdit, setOpenEdit] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Cancel dialog state
  const [openCancel, setOpenCancel] = useState(false);
  const [cancelOrder, setCancelOrder] = useState<Order | null>(null);

  // Fetch orders from backend whenever filters change
  const loadOrders = async () => {
    const res = await getOrders(filters);
    setOrders(res.data.data);
    setTotal(res.data.total);
  };

  useEffect(() => {
    loadOrders();
  }, [filters]);  // re-fetch every time any filter changes

  // Open edit dialog with the selected order's data
  const handleEdit = (order: Order) => {
    setSelectedOrder(order);
    setOpenEdit(true);
  };

  // Open cancel dialog for this order
  const handleCancelClick = (order: Order) => {
    setCancelOrder(order);
    setOpenCancel(true);
  };

  // Delete — confirm first, then call API
  const handleDelete = async (id: number) => {
    const result = await Swal.fire({
      title: "Delete Order?",
      text: "This cannot be undone.",
      icon:  "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Delete",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    try {
      await deleteOrder(id);
      await Swal.fire({
        title: "Deleted!",
        icon: "success",
        timer: 1500,
        showConfirmButton: false,
      });
      loadOrders();
    } catch {
      Swal.fire({ title: "Error", text: "Failed to delete.", icon: "error" });
    }
  };

  // DataGrid column definitions
  const columns: GridColDef[] = [
    {
      // S.No — calculated from page number so it keeps counting across pages
      field: "sno",
      headerName: "S.No",
      width: 70,
      sortable: false,
      renderCell: (params) => {
        const index = orders.findIndex((o) => o.order_id === params.row.order_id);
        return (filters.page - 1) * 10 + index + 1;
      },
    },
    { field: "order_code", headerName: "Order Code", width: 130 },
    { field: "customer_name", headerName: "Customer", width: 140 },
    {
      field: "order_date",
      headerName: "Date",
      width: 120,
      // Show as readable date, not raw ISO string
      renderCell: (params) => new Date(params.value).toLocaleDateString(),
    },
    { field: "product_name", headerName: "Product", width: 140 },
    {
      field: "price",
      headerName: "Price",
      width: 90,
      renderCell: (params) => `₹ ${params.value}`,
    },
    { field: "quantity", headerName: "Qty", width: 70 },
    {
      field: "total_amount",
      headerName: "Total",
      width: 100,
      renderCell: (params) => `₹ ${params.value}`,
    },
    {
      field: "order_status",
      headerName: "Status",
      width: 120,
      // Color coded chip — Pending=default, Delivered=success, Cancelled=error
      renderCell: (params) => (
        <Chip
          label={params.value}
          size="small"
          color={
            params.value === "Delivered" ? "success" :
            params.value === "Cancelled" ? "error"   : "default"
          }
        />
      ),
    },
    {
      field: "actions",
      headerName: "Actions",
      width: 240,
      sortable: false,
      renderCell: (params) => {
        const order = params.row as Order;
        return (
          <Box sx={{ display: "flex", gap: 1, alignItems: "center", height: "100%" }}>

            {/* Edit — disabled if order is already cancelled */}
            <AppButton
              size="small"
              onClick={() => handleEdit(order)}
              disabled={order.order_status === "Cancelled"}
            >
              Edit
            </AppButton>

            {/* Cancel — disabled if already cancelled */}
            <AppButton
              size="small"
              color="warning"
              onClick={() => handleCancelClick(order)}
              disabled={order.order_status === "Cancelled"}
            >
              Cancel
            </AppButton>

            {/* Delete — always available */}
            <AppButton
              size="small"
              color="error"
              onClick={() => handleDelete(order.order_id)}
            >
              Delete
            </AppButton>

          </Box>
        );
      },
    },
  ];

  return (
    <Box>

      {/* Search + Filter + Sort + Reset bar */}
      <OrderFilters
        filters={filters}
        setFilters={setFilters}
        onReset={() => setFilters(DEFAULT_FILTERS)}
      />

      {/* DataGrid — server-side pagination */}
      <Box sx={{ height: 520, mt: 2 }}>
        <DataGrid
          rows={orders}
          columns={columns}
          getRowId={(row) => row.order_id}   // use order_id as unique key, not default "id"
          rowCount={total}                    // total for pagination controls
          pageSizeOptions={[10]}
          paginationModel={{ page: filters.page - 1, pageSize: 10 }}
          paginationMode="server"             // tell DataGrid: don't paginate client-side
          onPaginationModelChange={(model) =>
            setFilters({ ...filters, page: model.page + 1 })
          }
          disableRowSelectionOnClick
        />
      </Box>

      {/* Edit Dialog */}
      <EditOrderDialog
        open={openEdit}
        setOpen={setOpenEdit}
        order={selectedOrder}
        reloadOrders={loadOrders}
      />

      {/* Cancel Dialog */}
      <CancelOrderDialog
        open={openCancel}
        setOpen={setOpenCancel}
        order={cancelOrder}
        reloadOrders={loadOrders}
      />

    </Box>
  );
}

export default AdminOrderTable;
