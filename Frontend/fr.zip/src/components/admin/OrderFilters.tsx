import { Box, TextField } from "@mui/material";
import AppSelect from "../common/AppSelect";
import AppButton from "../common/AppButton";
import type { OrderFilters } from "../../types/order";

type Props = {
  filters: OrderFilters;
  setFilters: (f: OrderFilters) => void;
  onReset: () => void;
};

// Status dropdown options
const STATUS_OPTIONS = [
  { value: "", label: "All" },
  { value: "Pending", label: "Pending" },
  { value: "Delivered", label: "Delivered" },
  { value: "Cancelled", label: "Cancelled" },
];

// Sort dropdown options
const SORT_OPTIONS = [
  { value: "order_date", label: "Order Date" },
  { value: "created_at", label: "Created Date" },
  { value: "total_amount",label: "Total Amount" },
];

// Filters bar — search, status, sort, and one reset button
function OrderFilters({ filters, setFilters, onReset }: Props) {

  // Update one filter field, reset page to 1 so results start fresh
  const handleChange = (field: keyof OrderFilters, value: string | number) => {
    setFilters({ ...filters, [field]: value, page: 1 });
  };

  return (
    <Box sx={{ display: "flex", gap: 2, mt: 2, flexWrap: "wrap", alignItems: "center" }}>

      {/* Search — by customer name, order code (backend handles customer param) */}
      <TextField
        label="Search customer"
        size="small"
        value={filters.search}
        onChange={(e) => handleChange("search", e.target.value)}
        sx={{ width: 200 }}
      />

      {/* Filter by status */}
      <AppSelect
        label="Status"
        value={filters.status}
        onChange={(val) => handleChange("status", val)}
        options={STATUS_OPTIONS}
        size="small"
        width={150}
      />

      {/* Sort by */}
      <AppSelect
        label="Sort by"
        value={filters.sort}
        onChange={(val) => handleChange("sort", val)}
        options={SORT_OPTIONS}
        size="small"
        width={160}
      />

      {/* One reset button — clears search + filter + sort all at once */}
      <AppButton variant="outlined" size="small" onClick={onReset}>
        Reset
      </AppButton>

    </Box>
  );
}

export default OrderFilters;
