import {
  Dialog, DialogTitle, DialogContent, DialogActions, TextField
} from "@mui/material";
import { useState } from "react";
import Swal from "sweetalert2";
import { cancelOrder } from "../../services/api";
import AppSelect from "../common/AppSelect";
import AppButton from "../common/AppButton";
import type { Order } from "../../types/order";

type Props = {
  open: boolean;
  setOpen: (v: boolean) => void;
  order: Order | null;
  reloadOrders: () => void;
};

// Common cancellation reasons in the dropdown
const REASON_OPTIONS = [
  { value: "Customer requested cancellation", label: "Customer requested cancellation" },
  { value: "Payment failed", label: "Payment failed" },
  { value: "Item out of stock", label: "Item out of stock" },
  { value: "Duplicate order", label: "Duplicate order" },
  { value: "Others", label: "Others" },
];

function CancelOrderDialog({ open, setOpen, order, reloadOrders }: Props) {
  const [reason, setReason] = useState("");  // selected dropdown value
  const [customReason, setCustomReason] = useState(""); // text when "Others" is chosen
  const [reasonError, setReasonError] = useState("");  // validation error

  // Reset state when dialog is closed
  const handleClose = () => {
    setReason("");
    setCustomReason("");
    setReasonError("");
    setOpen(false);
  };

  const handleConfirm = async () => {
    // Validation — reason must be selected
    if (!reason) {
      setReasonError("Please select a reason");
      return;
    }
    // If "Others" selected, the custom text box must also be filled
    if (reason === "Others" && !customReason.trim()) {
      setReasonError("Please enter a reason");
      return;
    }

    // Final reason — either the dropdown value or the custom text
    const finalReason = reason === "Others" ? customReason : reason;

    // Confirm popup before actually cancelling
    const result = await Swal.fire({
      title: "Cancel Order?",
      text: `Reason: ${finalReason}`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Cancel Order",
      cancelButtonText: "Go Back",
    });

    if (!result.isConfirmed) return;  // user clicked "Go Back"

    try {
      // cancelOrder sends: { order_status: "Cancelled", remarks: reason }
      await cancelOrder(order!.order_id, finalReason);

      await Swal.fire({
        title: "Cancelled!",
        text: "Order has been cancelled.",
        icon: "success",
        timer: 1500,
        showConfirmButton: false,
      });

      handleClose();
      reloadOrders();  // refresh table

    } catch {
      Swal.fire({ title: "Error", text: "Failed to cancel order.", icon: "error" });
    }
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="xs" fullWidth>
      <DialogTitle>Cancel Order</DialogTitle>

      <DialogContent>

        {/* Dropdown — pick a common reason */}
        <AppSelect
          label="Reason"
          value={reason}
          onChange={(val) => {
            setReason(val);
            setReasonError("");      // clear error when user picks something
            setCustomReason("");     // reset custom text when switching options
          }}
          options={REASON_OPTIONS}
        />

        {/* Show text box only when "Others" is selected */}
        {reason === "Others" && (
          <TextField
            fullWidth
            multiline
            rows={3}
            label="Enter reason"
            value={customReason}
            onChange={(e) => {
              setCustomReason(e.target.value);
              setReasonError("");
            }}
            sx={{ mt: 2 }}
          />
        )}

        {/* Validation error shown below the inputs */}
        {reasonError && (
          <p style={{ color: "red", marginTop: 8, fontSize: 13 }}>{reasonError}</p>
        )}

      </DialogContent>

      <DialogActions sx={{ p: 2, gap: 1 }}>
        {/* Back = close without cancelling */}
        <AppButton variant="outlined" onClick={handleClose}>
          Back
        </AppButton>
        {/* Confirm = validate + ask Swal confirm + call API */}
        <AppButton color="error" onClick={handleConfirm}>
          Cancel Order
        </AppButton>
      </DialogActions>
    </Dialog>
  );
}

export default CancelOrderDialog;
