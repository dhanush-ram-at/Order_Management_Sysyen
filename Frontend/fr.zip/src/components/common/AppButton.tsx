import { Button } from "@mui/material";

// Reusable button — consistent size + style across the whole app
type Props = {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "contained" | "outlined" | "text";
  color?: "primary" | "error" | "warning" | "inherit";
  fullWidth?: boolean;
  disabled?: boolean;
  size?: "small" | "medium" | "large";
  sx?: object;
};

function AppButton({
  children,
  onClick,
  variant = "contained",
  color = "primary",
  fullWidth,
  disabled,
  size = "medium",
  sx = {},
}: Props) {
  return (
    <Button
      variant={variant}
      color={color}
      onClick={onClick}
      fullWidth={fullWidth}
      disabled={disabled}
      size={size}
      sx={sx}
    >
      {children}
    </Button>
  );
}

export default AppButton;
