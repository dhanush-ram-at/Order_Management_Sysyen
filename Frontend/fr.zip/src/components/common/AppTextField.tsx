import { TextField } from "@mui/material";

// Reusable text field — used everywhere in forms
// Just pass label, name, value, onChange and it works
type Props = {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  type?: string;      // default "text", can be "password", "date", etc.
  error?: boolean;     // turns field red when true
  helperText?: string;   // shows error message below field
  InputLabelProps?: object;
};

function AppTextField({ label, name, value, onChange, type = "text", error, helperText, InputLabelProps }: Props) {
  return (
    <TextField
      fullWidth
      label={label}
      name={name}
      value={value}
      onChange={onChange}
      type={type}
      error={error}
      helperText={helperText}
      InputLabelProps={InputLabelProps}
      sx={{ mt: 2 }}
    />
  );
}

export default AppTextField;
