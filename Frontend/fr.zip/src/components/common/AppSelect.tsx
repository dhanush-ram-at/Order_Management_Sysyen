import { FormControl, InputLabel, Select, MenuItem } from "@mui/material";

// One option in the dropdown
type Option = {
  value: string;
  label: string;
};

// Reusable dropdown select — used in filters, forms, dialogs
type Props = {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Option[];
  size?: "small" | "medium";
  width?: number;
};

function AppSelect({ label, value, onChange, options, size = "medium", width }: Props) {
  return (
    <FormControl size={size} sx={{ mt: size === "medium" ? 2 : 0, width: width ?? "100%" }}>
      <InputLabel>{label}</InputLabel>
      <Select
        label={label}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((opt) => (
          <MenuItem key={opt.value} value={opt.value}>
            {opt.label}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
}

export default AppSelect;
