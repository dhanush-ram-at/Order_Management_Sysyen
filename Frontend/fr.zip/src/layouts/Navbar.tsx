import { AppBar, Toolbar, Typography, Button } from "@mui/material";
import Swal from "sweetalert2";
import { PAGE_ROUTES } from "../Routes/apiRoutes";

function Navbar() {
  // Read user info saved during login
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  const handleLogout = () => {
    // Ask user to confirm before logging out
    Swal.fire({
      title: "Logout?",
      text: "Are you sure you want to logout?",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Yes, Logout",
      cancelButtonText: "Cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        // Clear all saved data and go to login
        localStorage.removeItem("user");
        localStorage.removeItem("token");
        localStorage.removeItem("refreshToken");
        window.location.href = PAGE_ROUTES.LOGIN;
      }
    });
  };

  return (
    <AppBar position="static">
      <Toolbar>

        {/* Left side — app title */}
        <Typography sx={{ flexGrow: 1 }}>
          Order Management System
        </Typography>

        {/* Right side — user name, role, and logout button */}
        <Typography sx={{ mr: 2 }}>
          {user.name} ({user.role})   {/* e.g. "John (ADMIN)" */}
        </Typography>

        <Button color="inherit" onClick={handleLogout}>
          Logout
        </Button>

      </Toolbar>
    </AppBar>
  );
}

export default Navbar;
