import axios from "axios";
import API_ROUTES from "../Routes/apiRoutes";
import type { OrderFilters, OrderFormData } from "../types/order";

// Base axios instance — all requests go through this
export const api = axios.create({
  baseURL: "http://localhost:5000/api/v1",
});

// Automatically attach token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// If token expired (401) — try to refresh automatically
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      try {
        const refreshToken = localStorage.getItem("refreshToken");
        const res = await axios.post(API_ROUTES.AUTH.REFRESH, { refreshToken });
        localStorage.setItem("token", res.data.accessToken);
        original.headers.Authorization = `Bearer ${res.data.accessToken}`;
        return api(original);
      } catch {
        // Refresh also failed — clear everything and go to login
        localStorage.clear();
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export default api;

// ── Auth ──────────────────────────────────────────────────────────────────────

// Register a new user — name, email, password
export const registerUser = (data: { name: string; email: string; password: string }) => {
  return api.post(API_ROUTES.AUTH.REGISTER, data);
};

// ── Orders ────────────────────────────────────────────────────────────────────

// Get all orders with filters — page, search, status, sort
export const getOrders = (filters: OrderFilters) => {
  return api.get(API_ROUTES.ORDERS.BASE, {
    params: {
      page:     filters.page,
      customer: filters.search,   // backend reads "customer" param for name search
      status:   filters.status,
      sort:     filters.sort,
    },
  });
};

// Create a new order — FormData because it includes file uploads
export const createOrder = (data: any) => {
  return api.post(API_ROUTES.ORDERS.BASE, data);
};

// Update an order — plain JSON, no files
export const updateOrder = (id: number, data: Partial<OrderFormData>) => {
  return api.put(API_ROUTES.ORDERS.BY_ID(id), data);
};

// Cancel an order — sets status to Cancelled + stores the reason in remarks
export const cancelOrder = (id: number, reason: string) => {
  return api.put(API_ROUTES.ORDERS.BY_ID(id), {
    order_status: "Cancelled",
    remarks:      reason,          // reason saved in DB remarks column
  });
};

// Delete an order — soft delete on backend (sets is_deleted = true)
export const deleteOrder = (id: number) => {
  return api.delete(API_ROUTES.ORDERS.BY_ID(id));
};
