// Every API path lives here
// If you ever change /orders to /api/v1/orders — change it in ONE place only

const API_ROUTES = {

  BASE: "/api/v1",

  orders: {
    base:   "/orders",          // /api/v1/orders
    by_id:  "/orders/:id",             // /api/v1/orders/:id
  },

  UPLOADS: {
    base: "/uploads"
  },

};

module.exports = API_ROUTES;