// Sanitization = clean the incoming data before it touches your code
// We trim spaces and remove any HTML tags so nobody can inject bad code
// Example: "  <script>alert(1)</script>John  " becomes "John"

const sanitizeValue = (value) => {

  if (typeof value !== "string") return value;

  // Step 1 — remove leading and trailing spaces
  let clean = value.trim();

  // Step 2 — remove any HTML tags like <script>, <img>, <div> etc.
  clean = clean.replace(/<[^>]*>/g, "");

  return clean;

};

// This middleware loops over every field in req.body and cleans it
const sanitizeBody = (req, res, next) => {

  if (req.body && typeof req.body === "object") {

    for (const key in req.body) {
      req.body[key] = sanitizeValue(req.body[key]);
    }

  }

  next();

};

module.exports = sanitizeBody;