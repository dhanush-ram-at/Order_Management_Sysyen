// Repository = the ONLY place that talks to the database
// It runs the actual Prisma queries
// Services call repositories — never call Prisma from a service directly

const prisma = require("../config/prismaClient");

// Insert a new order row
const createOrder = async (data) => {
  const order = await prisma.order_placement.create({ data: data });
  return order;
};

// Get many orders with filters, pagination, sorting
const findAllOrders = async (filters, skip, limit, sort) => {
  const orders = await prisma.order_placement.findMany({
    where:   filters,
    skip:    skip,
    take:    limit,
    orderBy: { [sort]: "desc" }
  });
  return orders;
};

// Count total matching orders (used for pagination info)
const countOrders = async (filters) => {
  const total = await prisma.order_placement.count({ where: filters });
  return total;
};

// Get one order by its ID
const findOrderById = async (id) => {
  const order = await prisma.order_placement.findUnique({
    where: { order_id: id }
  });
  return order;
};

// Update an order by ID
const updateOrderById = async (id, data) => {
  return await prisma.order_placement.update({
    where: { order_id: id },
    data:  data
  });
  //return order;
};

// Soft delete — just sets is_deleted to true
const softDeleteOrderById = async (id) => {
  await prisma.order_placement.update({
    where: { order_id: id },
    data:  { is_deleted: true }
  });
};

module.exports = {
  createOrder,
  findAllOrders,
  countOrders,
  findOrderById,
  updateOrderById,
  softDeleteOrderById
};