const express    = require("express");
const cors = require("cors");
const app        = express();
const API_ROUTES = require("./constants/apiRoutes");

const { jsonParser,
        urlencodedParser } = require("./middlewares/bodyParser");
const errorHandler          = require("./middlewares/errorHandler");
const orderRoutes           = require("./routes/orderRoutes");

app.use(cors());
// Step 1 — body parsers (must be before routes)
app.use(jsonParser);
app.use(urlencodedParser);

// Step 2 — health check
app.get("/", (req, res) => {
  res.send("OMS backend is running");
});

// Step 3 — mount routes using the constant, not a hardcoded string
app.use(API_ROUTES.BASE, orderRoutes);
// All order routes are now at: /api/v1/orders

// Step 4 — serve uploaded files
app.use("/uploads", express.static("uploads"));

// Step 5 — error handler (must always be last)
app.use(errorHandler);
port  = 5000
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});