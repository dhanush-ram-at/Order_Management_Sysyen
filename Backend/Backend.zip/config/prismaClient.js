// DAL = Data Access Layer
// This file owns the Prisma connection
// Every repository imports from here — never import PrismaClient directly elsewhere

const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

module.exports = prisma;