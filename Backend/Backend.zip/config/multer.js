import React from 'react'

const multer = () => {
  return (
    port = 5000
  )
}

export default multer